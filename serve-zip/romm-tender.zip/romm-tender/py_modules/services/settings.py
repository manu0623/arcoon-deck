"""SettingsService — user-facing settings reads/writes and frontend-log routing.

Owns every callable that reads or mutates the live ``settings`` dict
from the frontend. Adapter-level I/O (Steam Input config, RetroArch
input driver) is reached via the ``SteamConfigStore`` Protocol;
on-disk persistence is fired through the injected
``save_settings_to_disk`` callable so the service never touches the
filesystem directly.

Frontend-log routing also lives here — it reads the configured level
from the live settings dict and dispatches to the runtime logger.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, ClassVar

from domain.custom_headers import (
    HeaderProblem,
    HeaderRefusal,
    resolve_custom_headers,
    stored_custom_headers,
)
from domain.sibling_resolution import AUTO_REGION
from lib.list_result import ErrorCode
from lib.url_host import is_valid_server_url

if TYPE_CHECKING:
    import logging

    from services.protocols import SettingsPersister, SteamConfigStore, UnitOfWorkFactory


_MASK_PLACEHOLDER = "••••"
_VALID_LOG_LEVELS = ("debug", "info", "warn", "error")
_VALID_STEAM_INPUT_MODES = ("default", "force_on", "force_off")

# What the user is told about a refused custom-header list. Each template may name
# the offending header, never its value. ``Authorization`` gets its own sentence
# because it is the first header a proxy's docs suggest and the one the RomM
# bearer already occupies — a user told only "reserved" would keep trying.
_HEADER_REFUSAL_MESSAGES: dict[HeaderProblem, str] = {
    HeaderProblem.NOT_A_LIST: "Custom headers must be a list of rows.",
    HeaderProblem.MALFORMED_ENTRY: "A custom header row is missing its name or value.",
    HeaderProblem.UNKNOWN_VALUE_ACTION: "Could not tell whether to keep or replace the value for '{name}'.",
    HeaderProblem.INVALID_NAME: (
        "'{name}' is not a valid header name — it may not contain a space or a colon; "
        "letters, digits and - _ . are safe."
    ),
    # Not "set by the plugin": two of the eight reserved names are not. `Host`
    # is set by nobody here (it is reserved because http.client suppresses its
    # own derived one once a caller supplies it) and `Content-Length` is set by
    # http.client, so a message naming the plugin is false for both.
    HeaderProblem.RESERVED_NAME: "'{name}' is set for you when the request is sent and cannot be overridden.",
    HeaderProblem.AUTHORIZATION_RESERVED: (
        "'Authorization' already carries your RomM API token, so it cannot also carry a proxy credential. "
        "Ask your proxy for a header of its own (Pangolin uses P-Access-Token and P-Access-Token-Id)."
    ),
    HeaderProblem.DUPLICATE_NAME: "'{name}' is listed more than once.",
    HeaderProblem.EMPTY_VALUE: "'{name}' needs a value.",
    HeaderProblem.UNSAFE_VALUE: "The value for '{name}' contains a line break or control character.",
    HeaderProblem.PADDED_VALUE: "The value for '{name}' starts or ends with a space — remove it.",
    HeaderProblem.UNENCODABLE_VALUE: "The value for '{name}' contains characters an HTTP header cannot carry.",
    HeaderProblem.UNEXPECTED_VALUE: "'{name}' asked to keep its stored value but sent one as well.",
    HeaderProblem.NO_STORED_VALUE: "'{name}' has no stored value to keep — enter one.",
}


def _header_refusal_message(refusal: HeaderRefusal) -> str:
    """Word a refusal for the user. A template with no ``{name}`` ignores the name."""
    return _HEADER_REFUSAL_MESSAGES[refusal.problem].format(name=refusal.name)


@dataclass(frozen=True)
class SettingsServiceConfig:
    """Frozen wiring bundle handed to ``SettingsService.__init__``.

    Carries the live settings dict, the SQLite Unit-of-Work factory (the
    read seam over the ``roms`` aggregate for the bound-shortcut app_ids
    ``apply_steam_input_setting`` re-skins), plus the runtime
    infrastructure (logger, settings persister, steam-config adapter).
    Bundled here so the ctor stays within the S107 parameter budget.
    """

    settings: dict[str, Any]
    uow_factory: UnitOfWorkFactory
    logger: logging.Logger
    settings_persister: SettingsPersister
    steam_config: SteamConfigStore


class SettingsService:
    """User-facing settings reads/writes, masking, and frontend-log routing."""

    LOG_LEVELS: ClassVar[dict[str, int]] = {"debug": 0, "info": 1, "warn": 2, "error": 3}

    def __init__(self, *, config: SettingsServiceConfig) -> None:
        self._settings = config.settings
        self._uow_factory = config.uow_factory
        self._logger = config.logger
        self._settings_persister = config.settings_persister
        self._steam_config = config.steam_config

    # ── Server connection settings ───────────────────────────────────────

    def save_server_url(self, romm_url: str, allow_insecure_ssl: bool | None = None) -> dict[str, Any]:
        """Persist the trimmed server URL and optional SSL flag.

        Rejects a blank or non-http(s) URL without writing anything.
        Credentials and tokens are never touched here — minting and
        storing the Client API Token is ``ConnectionService``'s job.
        ``allow_insecure_ssl=None`` leaves the SSL flag unchanged.

        This path deliberately does not re-stamp the stored token's origin, so
        pointing the URL at a different origin leaves the token's origin
        mismatched — the auth-header guard then fails data flows fast with
        ``config_error`` until the user signs in again (the intended #1039
        behavior for the no-sign-in URL-change path).
        """
        trimmed = romm_url.strip()
        if not is_valid_server_url(trimmed):
            return {"success": False, "reason": "config_error", "message": "Enter a valid http(s):// server URL"}
        try:
            self._settings["romm_url"] = trimmed
            if allow_insecure_ssl is not None:
                self._settings["romm_allow_insecure_ssl"] = bool(allow_insecure_ssl)
            self._settings_persister.save_settings()
            return {"success": True, "message": "Settings saved"}
        except Exception as e:
            self._logger.error(f"Failed to save settings: {e}")
            return {"success": False, "reason": "save_failed", "message": f"Save failed: {e}"}

    def save_custom_headers(self, headers: object) -> dict[str, Any]:
        """Validate and persist the extra headers sent to the RomM origin.

        Whole-list replace: the list handed in IS the new configuration, so a row
        the user removed is gone. Each entry states what to do with its value —
        ``"set"`` carries a new one, ``"keep"`` reuses the one stored under that
        name — because a stored value is never sent to the frontend and so cannot
        be echoed back. The whole list is refused on the first problem, and the
        refusal names the offending header, never its value.
        """
        stored = stored_custom_headers(self._settings.get("romm_custom_headers"))
        resolved = resolve_custom_headers(headers, stored)
        if isinstance(resolved, HeaderRefusal):
            return {
                "success": False,
                "reason": resolved.problem.value,
                "message": _header_refusal_message(resolved),
            }
        self._settings["romm_custom_headers"] = [{"name": h.name, "value": h.value} for h in resolved]
        self._settings_persister.save_settings()
        return {"success": True}

    def get_settings(self) -> dict[str, Any]:
        """Return the read-shape settings dict for the frontend.

        Reports whether a Client API Token is stored via ``has_token``;
        the token itself is never sent to the frontend. The SteamGridDB
        API key is reported as a masked placeholder. The custom proxy
        headers are reported by NAME only, for the same reason: a stored
        value can be replaced, never read back.
        """
        return {
            "romm_url": self._settings.get("romm_url", ""),
            "has_token": bool(self._settings.get("romm_api_token")),
            "steam_input_mode": self._settings.get("steam_input_mode", "default"),
            "sgdb_api_key_masked": _MASK_PLACEHOLDER if self._settings.get("steamgriddb_api_key") else "",
            "retroarch_input_check": self._steam_config.check_retroarch_input_driver(),
            "log_level": self._settings.get("log_level", "warn"),
            "romm_allow_insecure_ssl": self._settings.get("romm_allow_insecure_ssl", False),
            "collection_create_platform_groups": self._settings.get("collection_create_platform_groups", False),
            "collection_owner_scope": self._settings.get("collection_owner_scope", "all"),
            "collection_naming_mode": self._settings.get("collection_naming_mode", "merge"),
            "preferred_region": self._settings.get("preferred_region", AUTO_REGION),
            "skip_preview": self._settings.get("skip_preview", False),
            "romm_custom_header_names": [
                h.name for h in stored_custom_headers(self._settings.get("romm_custom_headers"))
            ],
        }

    # ── Log level ────────────────────────────────────────────────────────

    def save_log_level(self, level: str) -> dict[str, Any]:
        """Validate and persist the runtime log level."""
        if level not in _VALID_LOG_LEVELS:
            return {"success": False, "reason": "invalid_log_level", "message": "Invalid log level"}
        self._settings["log_level"] = level
        self._settings_persister.save_settings()
        return {"success": True}

    # ── Preferred region (sibling-group naming/binding) ──────────────────

    def save_preferred_region(self, region: object) -> dict[str, Any]:
        """Validate and persist the preferred sibling-group region (ADR-0021 §3).

        ``"auto"`` (the default) means no preference — the fixed build-time region
        order (World > USA > Europe > Japan) decides. Any other value lifts that
        region to the top of the ranking used to pick a group's representative
        and mint its shortcut name; it takes effect on the next sync (existing
        shortcuts keep their bound version and name). A blank value normalises to
        ``"auto"``. The region vocabulary is open-ended (RomM ships full-word
        regions), so any string is accepted as-is; a non-string from the
        untrusted frontend wire is rejected.
        """
        if not isinstance(region, str):
            return {"success": False, "reason": "invalid_region", "message": "Invalid region"}
        self._settings["preferred_region"] = region.strip() or AUTO_REGION
        self._settings_persister.save_settings()
        return {"success": True}

    # ── Skip preview (sync-button intent) ────────────────────────────────

    def save_skip_preview(self, enabled: object) -> dict[str, Any]:
        """Validate and persist whether a sync starts without asking first.

        User intent, stored for a reader to choose between ``sync_preview`` and
        ``start_sync`` when the sync button is pressed. The backend's own sync
        behaviour does not depend on it: both callables stay reachable and
        neither consults this value. Persisted so the choice can survive the
        panel closing; Main's toggle holds its own local state today and does
        not read this value. A non-bool from the untrusted frontend wire is
        rejected.
        """
        if not isinstance(enabled, bool):
            return {"success": False, "reason": "invalid_value", "message": "Invalid value"}
        self._settings["skip_preview"] = enabled
        self._settings_persister.save_settings()
        return {"success": True}

    def get_known_regions(self) -> list[str]:
        """Return the distinct region values present in the locally synced library.

        Reads the ``regions`` of every persisted ``roms`` row (ADR-0021 version
        metadata) and returns the distinct values, sorted alphabetically. This
        is the source for the "Preferred region" dropdown's non-anchor options —
        a purely local read, no server call. An empty library yields ``[]`` (the
        dropdown then shows only its fixed anchors).
        """
        regions: set[str] = set()
        with self._uow_factory() as uow:
            for rom in uow.roms.iter_all():
                regions.update(rom.regions)
        return sorted(regions)

    def frontend_log(self, level: str, message: str) -> None:
        """Log a frontend message respecting the configured log_level threshold.

        Messages below the configured threshold are dropped silently.
        Unknown level strings are treated as ``debug`` (the lowest
        threshold) so misrouted frontend calls still surface when
        ``log_level=debug``.
        """
        configured = self._settings.get("log_level", "warn")
        if self.LOG_LEVELS.get(level, 0) >= self.LOG_LEVELS.get(configured, 2):
            if level == "error":
                self._logger.error(f"[FE] {message}")
            elif level == "warn":
                self._logger.warning(f"[FE] {message}")
            else:
                self._logger.info(f"[FE] {message}")

    # ── Steam Input ──────────────────────────────────────────────────────

    def save_steam_input_setting(self, mode: str) -> dict[str, Any]:
        """Validate and persist the Steam Input mode preference."""
        if mode not in _VALID_STEAM_INPUT_MODES:
            return {"success": False, "reason": "invalid_mode", "message": f"Invalid mode: {mode}"}
        self._settings["steam_input_mode"] = mode
        self._settings_persister.save_settings()
        return {"success": True}

    def apply_steam_input_setting(self) -> dict[str, Any]:
        """Apply the current Steam Input mode to every bound ROM shortcut."""
        mode = self._settings.get("steam_input_mode", "default")
        with self._uow_factory() as uow:
            app_ids = [rom.shortcut_app_id for rom in uow.roms.iter_all() if rom.shortcut_app_id is not None]
        if not app_ids:
            return {"success": True, "message": "No shortcuts to update"}
        try:
            self._steam_config.set_steam_input_config(app_ids, mode=mode)
            return {"success": True, "message": f"Steam Input set to '{mode}' for {len(app_ids)} shortcuts"}
        except Exception as e:
            self._logger.error(f"Failed to apply Steam Input setting: {e}")
            return {"success": False, "reason": ErrorCode.UNKNOWN.value, "message": "Operation failed"}

    # ── RetroArch input driver ──────────────────────────────────────────

    def fix_retroarch_input_driver(self) -> dict[str, Any]:
        """Repair a problematic RetroArch ``input_driver`` value (``x`` -> ``sdl2``)."""
        return self._steam_config.fix_retroarch_input_driver()

    # ── Whitelist (non-Steam shortcut removal) ──────────────────────────

    def get_whitelist_settings(self) -> dict[str, Any]:
        """Return whitelist settings used by the non-Steam game removal feature."""
        return {
            "disabled_defaults": self._settings.get("whitelist_disabled_defaults", []),
            "custom_names": self._settings.get("whitelist_custom_names", []),
        }

    def update_whitelist_settings(self, disabled_defaults: object, custom_names: object) -> dict[str, Any]:
        """Validate and persist whitelist settings.

        Both arguments must be lists of strings. Anything else is
        rejected with an error response so a malformed frontend call
        cannot corrupt the on-disk shape.
        """
        if not isinstance(disabled_defaults, list) or not all(isinstance(s, str) for s in disabled_defaults):
            return {
                "success": False,
                "reason": "invalid_whitelist",
                "message": "disabled_defaults must be a list of strings",
            }
        if not isinstance(custom_names, list) or not all(isinstance(s, str) for s in custom_names):
            return {
                "success": False,
                "reason": "invalid_whitelist",
                "message": "custom_names must be a list of strings",
            }
        self._settings["whitelist_disabled_defaults"] = disabled_defaults
        self._settings["whitelist_custom_names"] = custom_names
        self._settings_persister.save_settings()
        return {"success": True}

    # ── Collection grouping ─────────────────────────────────────────────

    def save_collection_platform_groups(self, enabled: bool) -> dict[str, Any]:
        """Persist the collection platform-group toggle."""
        self._settings["collection_create_platform_groups"] = bool(enabled)
        self._settings_persister.save_settings()
        return {"success": True}

    def set_collection_owner_scope(self, scope: object) -> dict[str, Any]:
        """Validate and persist the QAM collection owner-scope (``"own"`` / ``"all"``).

        ``"all"`` (the default) syncs every collection the server lists;
        ``"own"`` restricts the sync + display to the signed-in user's own
        collections (virtual collections have no owner and always sync). An
        unrecognised value from the untrusted frontend wire is rejected
        with the canonical failure shape so a bad call cannot corrupt the setting.
        """
        if scope not in ("own", "all"):
            return {"success": False, "reason": "invalid_scope", "message": f"Invalid owner scope: {scope}"}
        self._settings["collection_owner_scope"] = scope
        self._settings_persister.save_settings()
        return {"success": True}

    def set_collection_naming_mode(self, mode: object) -> dict[str, Any]:
        """Validate and persist the Steam-collection naming mode (``"merge"`` / ``"by_label"``).

        ``"merge"`` (the default) unions same-named collections of any kind into
        one ``RomM: [<name>]`` Steam collection; ``"by_label"`` appends the fine
        type label (``RomM: [<name> (Franchise)]``) so same-named collections of
        different types stay separate. The change takes effect on the next normal
        sync — the reporter rebuilds the complete collection set under the new
        key and the frontend reconcile renames accordingly (no Force Full Sync).
        An unrecognised value from the untrusted frontend wire is rejected with
        the canonical failure shape so a bad call cannot corrupt the setting.
        """
        if mode not in ("merge", "by_label"):
            return {"success": False, "reason": "invalid_mode", "message": f"Invalid naming mode: {mode}"}
        self._settings["collection_naming_mode"] = mode
        self._settings_persister.save_settings()
        return {"success": True}

    # ── Corrupt-settings reset notice ───────────────────────────────────

    def dismiss_settings_reset_notice(self) -> dict[str, Any]:
        """Acknowledge the corrupt-settings reset and persist the dismissal.

        Pops the persistent ``_settings_reset_notice`` marker from the live
        settings dict and saves, so the QAM banner and game-detail cards stay
        down across reloads. Idempotent — a no-op save when no marker is set.
        """
        self._settings.pop("_settings_reset_notice", None)
        self._settings_persister.save_settings()
        return {"success": True}
