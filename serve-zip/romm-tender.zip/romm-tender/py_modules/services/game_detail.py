"""GameDetailService — game detail page data aggregation.

Aggregates the synced-ROM registry, install record, cached save-sync state,
firmware cache, cached ROM metadata, and achievement progress into a single
response payload for the frontend game detail page. Reads the relational state
from SQLite through the Unit of Work; the platform display name comes from the
offline ``kv_config`` cache (not stored on the ROM — see ADR-0003). Cross-service
reads (BIOS, achievements) go through callback-injected Protocols so the service
stays independent of other service modules.
"""

from __future__ import annotations

import os
from dataclasses import asdict, dataclass
from typing import TYPE_CHECKING, Any, cast

from models.metadata import AchievementSummary

from domain.bios_status import BIOS_LABEL_UNKNOWN, BIOS_LEVEL_UNKNOWN
from domain.platform_names import decode_platform_names
from domain.save_status import compute_save_sync_display
from lib.path_safety import PathTraversalError, safe_join

if TYPE_CHECKING:
    import logging

    from models.state import MetadataCacheEntry

    from domain.rom import Rom
    from domain.rom_install import RomInstall
    from domain.rom_save_sync_state import RomSaveSyncState
    from services.protocols import (
        AchievementsReader,
        ActiveCoreReader,
        AdoptionCandidateProbeFn,
        BiosChecker,
        Clock,
        PathExistsReader,
        RetroDeckPaths,
        SystemResolver,
        UnitOfWorkFactory,
    )

# kv_config key for the offline ``platform_slug → display_name`` cache the library
# sync refreshes every run. Read here so the game-detail panel shows "Super
# Nintendo" rather than the bare "snes" slug. Mirrors
# ``library.reporter._PLATFORM_NAMES_KEY``.
_PLATFORM_NAMES_KEY = "platform_names"

METADATA_TTL_SEC = 7 * 24 * 3600  # 7 days
ACHIEVEMENT_TTL_SEC = 3600  # 1 hour


@dataclass(frozen=True)
class GameDetailServiceConfig:
    """Frozen wiring bundle handed to ``GameDetailService.__init__``.

    Holds the live settings dict, runtime infrastructure, the clock seam, the
    SQLite Unit-of-Work factory (the read seam over the ``roms`` /
    ``rom_installs`` / ``rom_save_sync_states`` / ``rom_metadata`` / ``kv_config``
    aggregates), and the Protocol-typed reader adapters (``BiosChecker``,
    ``AchievementsReader``, ``ActiveCoreReader``) GameDetailService consults to
    assemble the game-detail payload. The active-core resolver answers "which
    ``.so`` will this ROM launch with?" so the core-aware BIOS filter keys off
    the per-game pin, not a platform default. ``path_exists`` /
    ``retrodeck_paths`` / ``resolve_system`` are the single ``stat`` the page
    runs on an uninstalled ROM's target path; ``candidate_probe`` is the one
    ``readdir`` beside it, answering whether the same game is in the folder under
    another name. Both are bounded and network-free, which is the whole
    constraint on this page.
    """

    settings: dict[str, Any]
    logger: logging.Logger
    clock: Clock
    uow_factory: UnitOfWorkFactory
    bios_checker: BiosChecker
    achievements: AchievementsReader
    active_core: ActiveCoreReader
    path_exists: PathExistsReader
    retrodeck_paths: RetroDeckPaths
    resolve_system: SystemResolver
    candidate_probe: AdoptionCandidateProbeFn


class GameDetailService:
    """Aggregates game detail page data from SQLite + cross-service readers."""

    def __init__(self, *, config: GameDetailServiceConfig) -> None:
        self._settings = config.settings
        self._logger = config.logger
        self._clock = config.clock
        self._uow_factory = config.uow_factory
        self._bios_checker = config.bios_checker
        self._achievements = config.achievements
        self._active_core = config.active_core
        self._path_exists = config.path_exists
        self._retrodeck_paths = config.retrodeck_paths
        self._resolve_system = config.resolve_system
        self._candidate_probe = config.candidate_probe

    @staticmethod
    def _resolve_rom_file(install: RomInstall | None, rom: Rom) -> str:
        """ROM filename from the install record, falling back to ``Rom.fs_name``."""
        if install is not None and install.file_path:
            return os.path.basename(install.file_path)
        return rom.fs_name

    @staticmethod
    def _bios_answer(
        bios_status: dict[str, Any] | None = None,
        bios_level: str | None = None,
        bios_label: str | None = None,
        *,
        unknown: bool = False,
    ) -> dict[str, Any]:
        """Build the BIOS half of a game-detail payload.

        ``unknown`` marks a payload that carries no BIOS answer — the check
        raised, or answered from a source that could not see the requirement —
        as opposed to the answer "the active core needs no BIOS". The two ship
        the same absent ``bios_status``, and only the latter may take a shown
        requirement off the frontend, so the flag is what separates them.

        Those two reasons for the flag are themselves different answers, and the
        LEVEL is what separates them: a check that ran and could not establish
        the requirement ships ``bios_level`` ``"unknown"``, a read that never
        happened ships none. Both leave a shown requirement alone; only the first
        is something to show in its own right.
        """
        return {
            "bios_status": bios_status,
            "bios_level": bios_level,
            "bios_label": bios_label,
            "bios_status_unknown": unknown,
        }

    @staticmethod
    def _build_save_status(save_state: RomSaveSyncState | None) -> dict[str, Any] | None:
        """Build cached save-sync status from the ROM's save state, or None."""
        if save_state is None:
            return None
        # Every persisted file row carries a non-empty last_sync_hash (NOT NULL in
        # rom_save_files; both RomSaveSyncState writers reject an empty hash), so a
        # tracked file is always "synced" here.
        files_list = [
            {
                "filename": fn,
                "status": "synced",
                "last_sync_at": fdata.last_sync_at or None,
            }
            for fn, fdata in save_state.files.items()
        ]
        return {
            "files": files_list,
            "last_sync_check_at": save_state.last_sync_check_at,
            "conflicts": [],  # cached only — full conflicts via get_save_status()
        }

    def _build_achievement_summary(self, rom_id_str: str, ra_id: int | None) -> dict[str, Any] | None:
        """Build cached achievement summary for badge rendering, or None."""
        if not ra_id or not self._achievements.get_ra_username():
            return None
        cached_progress = self._achievements.get_progress_cache_entry(rom_id_str)
        if not cached_progress:
            return None
        return asdict(
            AchievementSummary(
                earned=cached_progress.get("earned", 0),
                total=cached_progress.get("total", 0),
                earned_hardcore=cached_progress.get("earned_hardcore", 0),
                cached_at=cached_progress.get("cached_at", 0.0),
            )
        )

    @staticmethod
    def _project_metadata(cached) -> MetadataCacheEntry | None:
        """Project the cached ``RomMetadata`` aggregate into the frontend entry shape.

        Returns the metadata entry (tuple fields flattened to list arrays,
        nullable date/rating preserved) or ``None`` on a cache miss — the
        ``None`` drives ``"metadata"`` into stale_fields so the frontend
        triggers a background refresh.
        """
        if cached is None:
            return None
        return cast(
            "MetadataCacheEntry",
            {
                "summary": cached.summary,
                "genres": list(cached.genres),
                "companies": list(cached.companies),
                "first_release_date": cached.first_release_date,
                "average_rating": cached.average_rating,
                "game_modes": list(cached.game_modes),
                "player_count": cached.player_count,
                "cached_at": cached.cached_at,
                "steam_categories": list(cached.steam_categories),
            },
        )

    @staticmethod
    def _compute_stale_fields(
        *,
        now: float,
        metadata: MetadataCacheEntry | None,
        platform_slug: str,
        ra_id: int | None,
        achievement_summary: dict[str, Any] | None,
    ) -> list[str]:
        """Return list of cache keys that are stale and need background refresh.

        ``bios`` is stale for every platform, unconditionally: this payload never
        carries a BIOS answer, so there is always one to fetch. It has no TTL for
        the same reason — a staleness marker needs something stored to age.
        """
        stale: list[str] = []

        meta_cached_at = metadata.get("cached_at", 0) if metadata else 0
        if not metadata or (now - meta_cached_at) > METADATA_TTL_SEC:
            stale.append("metadata")

        if platform_slug:
            stale.append("bios")

        if ra_id:
            if achievement_summary:
                if (now - achievement_summary.get("cached_at", 0)) > ACHIEVEMENT_TTL_SEC:
                    stale.append("achievements")
            else:
                stale.append("achievements")

        return stale

    def get_cached_game_detail(self, app_id) -> dict[str, Any]:
        """Return cached data for a game keyed by its Steam ``app_id``."""
        app_id = int(app_id)

        # ── Single unified read UoW (ADR-0006): one transaction reads the ROM,
        # its install/save-state/metadata children, and the platform-name cache.
        # Capture locals, close the UoW, then build the response and call the
        # bios_checker (HTTP-free cache read) entirely outside the transaction —
        # no I/O of any kind runs inside the ``with`` block.
        with self._uow_factory() as uow:
            rom = uow.roms.get_by_app_id(app_id)
            if rom is None:
                return {"found": False}
            rom_id = rom.rom_id
            install = uow.rom_installs.get(rom_id)
            save_state = uow.rom_save_sync_states.get(rom_id)
            metadata_raw = uow.rom_metadata.get(rom_id)
            platform_names = decode_platform_names(uow.kv_config.get(_PLATFORM_NAMES_KEY))

        rom_id_str = str(rom_id)
        platform_slug = rom.platform_slug
        ra_id = rom.ra_id

        installed = install is not None
        rom_file = self._resolve_rom_file(install, rom)
        target_occupied = False if installed else self._target_path_occupied(rom)
        # An occupied target and a candidate elsewhere are different states, and
        # the occupied one wins: it is the exact path this ROM would claim, so
        # there is nothing to search for. An installed ROM does neither.
        #
        # The slug goes in alone because the row holds no `platform_fs_slug`.
        # For a platform the resolver's map misses, the RomM slug is then taken
        # verbatim as a directory name — which is why the probe refuses to search
        # a directory ES-DE does not list as a system rather than trusting that
        # such a directory cannot exist.
        candidate_present = (
            False if installed or target_occupied else self._candidate_probe(rom.platform_slug, rom.fs_name)
        )

        # Save sync
        save_sync_enabled = bool(self._settings.get("save_sync_enabled", False))
        save_status = self._build_save_status(save_state)
        save_sync_display = None
        if save_status is not None:
            save_sync_display = asdict(
                compute_save_sync_display(
                    save_status["files"],
                    save_status.get("last_sync_check_at"),
                )
            )

        metadata = self._project_metadata(metadata_raw)

        # Platform display name from the offline cache, degrading to the slug.
        platform_name = platform_names.get(platform_slug, platform_slug) if platform_slug else ""

        # No BIOS answer rides this payload. What an emulator wants is read off
        # the machine, and an answer read for a previous page open may not stand
        # in for this one — so the page opens not-knowing and fills the answer in
        # from the live ``get_bios_status`` a moment later.
        bios_status = None
        bios_level = None
        bios_label = None
        bios_status_unknown = bool(platform_slug)

        # Achievement summary (for badge rendering)
        achievement_summary = self._build_achievement_summary(rom_id_str, ra_id)

        stale_fields = self._compute_stale_fields(
            now=self._clock.time(),
            metadata=metadata,
            platform_slug=platform_slug,
            ra_id=ra_id,
            achievement_summary=achievement_summary,
        )

        return {
            "found": True,
            "rom_id": rom_id,
            "rom_name": rom.name,
            "platform_slug": platform_slug,
            "platform_name": platform_name,
            "installed": installed,
            "save_sync_enabled": save_sync_enabled,
            "save_status": save_status,
            "save_sync_display": save_sync_display,
            "metadata": metadata,
            "bios_status": bios_status,
            "bios_level": bios_level,
            "bios_label": bios_label,
            "bios_status_unknown": bios_status_unknown,
            "rom_file": rom_file,
            "ra_id": ra_id,
            "achievement_summary": achievement_summary,
            "stale_fields": stale_fields,
            # Version metadata (ADR-0021): the sibling-group dimensions RomM
            # supplies per ROM, surfaced read-only in the game-detail "Version"
            # row. Tuples are flattened to JSON arrays for the wire.
            "regions": list(rom.regions),
            "languages": list(rom.languages),
            "revision": rom.revision,
            "tags": list(rom.tags),
            "is_main_sibling": rom.is_main_sibling,
            # Server-reported ROM size in bytes (#1395), surfaced read-only so the
            # frontend can show the space a download needs. NULL = size unknown.
            "fs_size_bytes": rom.fs_size_bytes,
            "target_path_occupied": target_occupied,
            "adoption_candidate_present": candidate_present,
        }

    def _target_path_occupied(self, rom: Rom) -> bool:
        """Whether something already sits where a download of *rom* would write.

        The one ``stat`` this network-free page runs, and only for a ROM with no
        install record — an existing row already answers the question. It exists
        so the page can say a file is already in place instead of offering an
        undifferentiated Download; the full comparison happens at click time
        (ADR-0028).

        The path is derived from ``roms.fs_name``, which is exact for the
        ordinary case. For a ROM RomM serves as a folder holding a single nested
        file, the on-disk name comes from server data this page does not have, so
        the computed path simply misses and this stays false. That degradation is
        intended: it goes quiet rather than claiming something it cannot know.
        """
        roms_path = self._retrodeck_paths.roms_path()
        if not roms_path or not rom.fs_name or not rom.platform_slug:
            return False
        try:
            target = safe_join(roms_path, self._resolve_system(rom.platform_slug), rom.fs_name)
        except PathTraversalError:
            return False
        return self._path_exists.exists(target)

    async def get_bios_status(self, rom_id) -> dict[str, Any]:
        """Return BIOS status for a ROM by looking up platform/rom_file from SQLite.

        Response always includes ``bios_status`` (dict or ``None``), ``bios_level``
        (``"ok"`` / ``"partial"`` / ``"missing"`` / ``"unknown"`` or ``None``),
        ``bios_label`` (str or ``None``), and ``bios_status_unknown`` (bool). The
        level and label are the checker's own — derived where the reading state
        that decides them is known and threaded through untouched, never
        re-derived here; the flag separates a check that could not answer from
        the answer "this core needs no BIOS", which is the only one of the two
        that clears a shown requirement.

        Two of the four outcomes carry a level: a requirement, and the answer
        ``"unknown"`` from a check that ran without establishing one. A check
        that raised carries none, and that absence is how the frontend tells a
        failed read from an answer it should render; so does the fourth, the
        plain "no BIOS needed".
        """
        rom_id = int(rom_id)

        # Short read UoW: resolve platform_slug, then await the BIOS check OUTSIDE
        # the transaction (ADR-0006 — no network I/O in the UoW).
        with self._uow_factory() as uow:
            rom = uow.roms.get(rom_id)

        if rom is None:
            return self._bios_answer()

        platform_slug = rom.platform_slug
        if not platform_slug:
            return self._bios_answer()

        # The BIOS filter keys off the per-game emulator (the pin over the
        # system default), resolved by rom_id from the shared seam. The whole
        # resolution goes over, not one field of it: the checker filters by its
        # IDENTITY — the one field naming a standalone emulator as well as a
        # libretro core, where ``active_core_for_rom`` would answer ``None`` for
        # the first and send the page back to the platform's own pick — and
        # names it by its LABEL, and a caller splitting those is how a page comes
        # to name one emulator and judge by another.
        emulator = self._active_core.active_emulator_for_rom(rom_id)

        try:
            bios = await self._bios_checker.check_platform_bios(platform_slug, launching_emulator=emulator)
            if bios.get("needs_bios"):
                # The checker's payload IS the wire shape, plus the slug it was
                # asked about. Re-wrapping it through ``format_bios_status`` here
                # would ship that dataclass's ``reading_complete`` default beside
                # the answer — a field no frontend models and whose True is a
                # claim this call site cannot make.
                return self._bios_answer(
                    {**bios, "platform_slug": platform_slug},
                    bios.get("bios_level"),
                    bios.get("bios_label"),
                )
        except Exception as e:
            self._logger.warning(f"BIOS status check failed for {platform_slug}: {e}")
            return self._bios_answer(unknown=True)

        # No requirement — but a check that itself degraded to a source blind to
        # the requirement reports that, and its verdict travels on unchanged. It
        # travels as a LEVEL as well as a flag: the flag alone is also what a
        # failed read ships (the ``except`` above), and the frontend has to tell
        # the two apart — an answer of "unknown" is shown as one, while a read
        # that never happened leaves whatever is on the page standing (#1693).
        if bios.get("bios_status_unknown"):
            return self._bios_answer(bios_level=BIOS_LEVEL_UNKNOWN, bios_label=BIOS_LABEL_UNKNOWN, unknown=True)
        return self._bios_answer()
