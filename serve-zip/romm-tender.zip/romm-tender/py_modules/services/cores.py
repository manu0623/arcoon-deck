"""CoreService — RetroArch core selection and overrides per platform/ROM.

Owns the plugin's two core-selection deviations: the per-platform core (the
``settings.json`` ``platform_cores`` map) and the per-game emulator override (the
``roms.emulator_override`` pin). Enumerating the cores available for a platform —
by slug, or for a ROM with its per-game pin layered on top — toggling the
per-platform default (with the fan-out that re-bakes every affected shortcut),
and pinning/clearing a per-game core all live here; the
cross-service BIOS recheck that follows a per-platform core write is also
scheduled from this service.

Neither selection is written to the retired ES-DE gamelist: the per-platform core
lands in ``settings.json`` via the injected ``SettingsPersister`` and the per-game
pin lands on the ``Rom`` aggregate via the Unit-of-Work. The launch command for an
installed+bound ROM is recomputed from the shared ``ActiveCoreReader`` resolver so
the read-path core never diverges from the launched core, and the frontend can
confirm-set the freshly-baked ``launch_options`` on the live Steam shortcut.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Any

from domain.emulator_commands import (
    EmulatorOption,
    label_to_invocation,
    options_to_payload,
    resolve_platform_label,
)
from domain.emulator_picker import external_options, with_external
from domain.retroarch_appendconfig import with_appendconfig
from domain.retroarch_runner import resolve_backend
from domain.shortcut_data import (
    EmulatorInvocation,
    build_launch_options,
    resolve_emulator_invocation,
)
from lib.list_result import ErrorCode

if TYPE_CHECKING:
    import asyncio
    import logging

    from domain.rom import Rom
    from domain.rom_install import RomInstall
    from services.protocols import (
        ActiveCoreReader,
        BiosChecker,
        CoreInfoProvider,
        DiscResolver,
        ExternalEmulatorProvider,
        RetroArchAppendConfigFn,
        RetroArchRunnerFn,
        SettingsPersister,
        SystemResolver,
        UnitOfWorkFactory,
    )


@dataclass(frozen=True)
class CoreServiceConfig:
    """Frozen wiring bundle handed to ``CoreService.__init__``.

    Carries the runtime infrastructure (event loop, logger), the ES-DE
    core-info read seam, the platform-slug-to-system resolver, the live
    ``settings`` dict + its persister (where the per-platform core lands), the
    cross-service BIOS checker, the SQLite Unit-of-Work factory (to read the ROM
    + its install and write the per-game pin), the shared per-ROM
    active-core resolver (the menu's active marker + the source of every
    re-baked launch command), and the shared per-ROM disc resolver (so a re-baked
    launch command keeps the ROM's pinned disc rather than reverting to disc 1 /
    the m3u). Bundled here so the ctor stays within the S107 parameter budget.
    """

    loop: asyncio.AbstractEventLoop
    logger: logging.Logger
    core_info: CoreInfoProvider
    resolve_system: SystemResolver
    settings: dict[str, Any]
    settings_persister: SettingsPersister
    bios_checker: BiosChecker
    uow_factory: UnitOfWorkFactory
    active_core: ActiveCoreReader
    disc_resolver: DiscResolver
    # Optional so every existing test and wiring keeps working while the inventory
    # is absent; ``None`` means "offer only the catalogue's rows", never "none
    # installed", which is a list the provider itself answers.
    external_emulators: ExternalEmulatorProvider | None = None
    # Optional: the generated RetroArch config a resolved libretro launch carries. The
    # pin write path bakes its own invocation, so it must attach the same file the
    # resolver does or a re-bake would quietly drop the save redirection.
    retroarch_appendconfig: RetroArchAppendConfigFn | None = None
    # Optional: resolves a RetroArch the plugin can start directly for a given core.
    # The pin path bakes its own invocation, so without this seam a re-pin would move a
    # shortcut back through RetroDECK while the resolver kept launching owned.
    retroarch_runner: RetroArchRunnerFn | None = None


class CoreService:
    """RetroArch core override reads and writes — per-platform (settings) + per-game (DB)."""

    def __init__(self, *, config: CoreServiceConfig) -> None:
        self._loop = config.loop
        self._logger = config.logger
        self._core_info = config.core_info
        self._resolve_system = config.resolve_system
        self._settings = config.settings
        self._settings_persister = config.settings_persister
        self._bios_checker = config.bios_checker
        self._uow_factory = config.uow_factory
        self._active_core = config.active_core
        self._disc_resolver = config.disc_resolver
        self._external_emulators = config.external_emulators
        self._appendconfig = config.retroarch_appendconfig
        self._retroarch_runner = config.retroarch_runner

    async def get_platform_core_info(self, rom_id: int) -> dict[str, Any]:
        """Return the emulators available for ``rom_id``'s platform + the active one.

        The emulator list is platform-wide (system-level): every ES-DE
        ``<command>`` for the ROM's system, each annotated ``{label, kind,
        core_so, emulator, is_default, bakeable, reason}`` (libretro AND
        standalone). The active selection is the per-ROM resolution from
        :class:`ActiveCoreResolver`, so a pinned ``emulator_override`` (or
        per-platform core) surfaces over the system default and the menu can
        highlight the active emulator (or offer Reset).

        ``active_core`` and ``active_core_label`` are two projections of that ONE
        resolution, and ``active_core`` is the emulator IDENTITY — the same
        spelling the ``emulator`` field of each picker entry carries and the same
        one a firmware row's per-emulator map is keyed on, so the BIOS pane can
        match its answer against the pick it was scoped to. ``active_core_for_rom``
        cannot serve it: its ``core_so`` is ``None`` for every standalone
        emulator and omits the extension for a libretro one, which is two
        identifier spaces on one payload. ``platform_core_label``
        carries the per-platform override label (``settings.json``
        ``platform_cores``) so the menu can mark the system-level selection
        distinctly from the active emulator. ``has_game_override`` reports
        whether a per-game pin is set — the menu can't infer this from the active
        emulator alone (pinning the same emulator as the per-platform override is
        indistinguishable), so the flag drives the "follow the system" reset
        item's checkmark. ``emulator_data_available`` is ``False`` when
        ``es_systems.xml`` cannot be read (RetroDECK not detected), so the menu
        can say so instead of showing an empty list. When ``rom_id`` is unknown
        the emulator list is empty and the active emulator is ``(None, None)``.
        """
        return await self._loop.run_in_executor(None, self._platform_core_info_io, rom_id)

    def _merged_options(self, options: list[EmulatorOption], platform_slug: str) -> list[EmulatorOption]:
        """The catalogue's rows plus the externally installed emulators for *platform*.

        Appended, never interleaved: ES-DE's order is the distro's curation and its
        first bakeable entry stays the default. The rows this adds are not bakeable
        yet (see :mod:`domain.emulator_picker`), so they can appear in the menu
        without ever becoming what launches.

        An empty external list — no ``~/Applications``, no flatpak, no EmuDeck — is
        the normal answer on a stock Deck and changes nothing.
        """
        provider = self._external_emulators
        if provider is None:
            return options
        return with_external(options, external_options(provider.for_platform(platform_slug), platform_slug))

    def _platform_core_info_io(self, rom_id: int) -> dict[str, Any]:
        rom = self._read_rom(rom_id)
        if rom is None:
            return {
                "emulators": [],
                "emulator_data_available": True,
                "active_core": None,
                "active_core_label": None,
                "platform_core_label": None,
                "has_game_override": False,
            }
        system = self._resolve_system(rom.platform_slug)
        options = self._core_info.get_emulator_options(system)
        options = {**options, "options": self._merged_options(options["options"], rom.platform_slug)}
        emulator = self._active_core.active_emulator_for_rom(rom_id)
        return {
            "emulators": options_to_payload(options["options"]),
            "emulator_data_available": options["available"],
            "active_core": emulator.emulator if emulator is not None else None,
            "active_core_label": emulator.label if emulator is not None else None,
            "platform_core_label": self._settings.get("platform_cores", {}).get(rom.platform_slug),
            "has_game_override": rom.emulator_override is not None,
        }

    async def get_system_core_info(self, platform_slug: str) -> dict[str, Any]:
        """Return the emulators available for *platform_slug* + the active one.

        The read half of :meth:`set_system_core`, keyed by platform rather than
        by ROM: the Library page's Platforms detail asks it once per selected
        platform. ``emulators`` is the full classified picker payload for the
        platform's ES-DE system, ``emulator_data_available`` is ``False`` when
        ``es_systems.xml`` cannot be read (RetroDECK not detected), and
        ``active_core_label`` is the platform-layer resolution — the per-platform
        override when it still resolves, else the es_systems default — so the
        label and a launch from this platform agree.

        Distinct from :meth:`get_platform_core_info`, which answers the same
        question for one ROM and layers that ROM's ``emulator_override`` on top;
        a platform-keyed caller has no ROM to layer and must be answerable for a
        platform holding no synced ROM at all.
        """
        return await self._loop.run_in_executor(None, self._system_core_info_io, platform_slug)

    def _system_core_info_io(self, platform_slug: str) -> dict[str, Any]:
        system = self._resolve_system(platform_slug)
        options = self._core_info.get_emulator_options(system)
        options = {**options, "options": self._merged_options(options["options"], platform_slug)}
        return {
            "emulators": options_to_payload(options["options"]),
            "emulator_data_available": options["available"],
            "active_core_label": resolve_platform_label(
                options["options"], self._settings.get("platform_cores", {}).get(platform_slug)
            ),
        }

    def _set_system_core_io(self, platform_slug: str, core_label: str) -> list[dict[str, Any]]:
        """Write the per-platform core selection and re-bake the affected shortcuts.

        Mutates ``settings["platform_cores"]`` — stores *core_label* under
        *platform_slug* when non-empty, pops the slug when blank (revert to the
        es_systems default) — and persists ``settings.json`` through the
        injected persister. The persister holds the same live dict, so the fan-out
        that follows resolves the freshly-written value.

        Returns one ``{"app_id", "launch_options"}`` entry per installed+bound ROM
        on the platform whose active core is the new per-platform selection. ROMs
        with a per-game ``emulator_override`` are skipped (the pin wins over the
        platform default), as are uninstalled or unbound ROMs (no live shortcut to
        rewrite). Each entry's ``launch_options`` is the FULL active core baked by
        the shared resolver — the ``-e`` override form, or the plain launch when
        the resolver yields ``(None, None)`` — over the disc-resolved bake path,
        so a multi-disc ROM keeps its persisted ``selected_disc`` rather than
        reverting to disc 1 / the m3u (a single-disc ROM bakes its ``file_path``
        unchanged).
        """
        if core_label:
            self._settings["platform_cores"][platform_slug] = core_label
        else:
            self._settings["platform_cores"].pop(platform_slug, None)
        self._settings_persister.save_settings()
        self._core_info.reset_cache()

        # Snapshot the installed+bound, non-overridden (rom, install) pairs in one
        # short read UoW, then close it before resolving each ROM's active core:
        # active_emulator_for_rom opens its own UoW, and the per-connection
        # BEGIN IMMEDIATE write lock is not re-entrant — resolving inside the
        # iteration UoW would block on the lock until busy_timeout then raise
        # "database is locked" (#1134). This read UoW performs no writes.
        pending: list[tuple[Rom, RomInstall]] = []
        with self._uow_factory() as uow:
            for rom in uow.roms.iter_by_platform(platform_slug):
                if rom.emulator_override is not None:
                    continue
                if rom.shortcut_app_id is None:
                    continue
                install = uow.rom_installs.get(rom.rom_id)
                if install is None:
                    continue
                pending.append((rom, install))

        rebake_items: list[dict[str, Any]] = []
        for rom, install in pending:
            emulator = self._active_core.active_emulator_for_rom(rom.rom_id)
            invocation = resolve_emulator_invocation({}, emulator)
            # Fold the ROM's persisted disc pick over the install so a
            # per-platform core change re-bakes the pinned disc, not disc 1 /
            # the m3u. A single-disc ROM resolves to its own file_path.
            bake_path = self._disc_resolver.resolve_for_install(install, rom.selected_disc)
            rebake_items.append(
                {
                    "app_id": rom.shortcut_app_id,
                    "launch_options": build_launch_options(invocation, bake_path),
                }
            )
        return rebake_items

    async def set_system_core(self, platform_slug: str, core_label: str) -> dict[str, Any]:
        """Set or clear the per-platform core selection for a platform.

        Empty ``core_label`` clears the selection (reverts to the es_systems
        default). On success the per-platform core is written to ``settings.json``
        and every installed+bound ROM on the platform (minus per-game-overridden
        ROMs) is re-baked: the response carries ``rebake_items`` (a list of
        ``{"app_id", "launch_options"}``) the frontend confirm-sets on the live
        Steam shortcuts, plus ``bios_status`` re-checked against the newly chosen
        core. On any failure (settings write error, fan-out error, BIOS recheck
        error) returns ``{"success": False, "message": ...}``.
        """
        try:
            rebake_items = await self._loop.run_in_executor(
                None,
                self._set_system_core_io,
                platform_slug,
                core_label,
            )
            bios = await self._bios_checker.check_platform_bios(platform_slug)
            return {"success": True, "bios_status": bios, "rebake_items": rebake_items}
        except Exception as e:
            self._logger.error(f"Failed to set system core: {e}")
            return {"success": False, "reason": ErrorCode.UNKNOWN.value, "message": str(e)}

    async def set_game_core(self, rom_id: int, label: str) -> dict[str, Any]:
        """Pin the per-game emulator override for ``rom_id`` to *label*.

        The picked LABEL is resolved to a bakeable :class:`EmulatorInvocation`
        FIRST (against the emulators ES-DE lists for the ROM's platform, libretro
        OR standalone). A label that does not resolve to a bakeable emulator —
        unknown, ``needs_setup``, or otherwise un-bakeable — is a hard failure:
        the canonical ``{"success": False, "reason": ..., "message": ...}`` shape
        is returned and **nothing is written**, so the DB never holds a label no
        consumer can bake. On success the pin is written via the Unit-of-Work and
        the response carries the freshly-baked ``launch_options`` (the ``-e``
        override form) and ``app_id`` for the frontend to confirm-set on the live
        Steam shortcut. When the ROM is not installed or not bound to a shortcut
        there is nothing to update live: the pin still lands and
        ``launch_options``/``app_id`` are ``None`` (the override applies on the
        next download).
        """
        return await self._loop.run_in_executor(None, self._set_game_core_io, rom_id, label)

    def _set_game_core_io(self, rom_id: int, label: str) -> dict[str, Any]:
        with self._uow_factory() as uow:
            rom = uow.roms.get(rom_id)
            if rom is None:
                return {
                    "success": False,
                    "reason": "not_found",
                    "message": f"ROM {rom_id} is not tracked",
                }
            platform_slug = rom.platform_slug
        # Resolve the label between the two transactions: the emulator-options
        # read re-probes ES-DE's config and each option's install on every call
        # (the slug→system resolver only on the process's first), and a UoW
        # holds SQLite's BEGIN IMMEDIATE write lock — file I/O inside one stalls
        # every other writer for its duration.
        system = self._resolve_system(platform_slug)
        invocation = label_to_invocation(self._core_info.get_emulator_options(system)["options"], label)
        if invocation is not None:
            invocation = with_appendconfig(invocation, self._appendconfig_for(platform_slug))
            invocation = self._maybe_owned(invocation)
        if invocation is None:
            # Hard-fail BEFORE any write — never persist a label that does not
            # resolve to a bakeable emulator (unknown / needs_setup / un-bakeable).
            return {
                "success": False,
                "reason": "core_unavailable",
                "message": f"Emulator '{label}' is not available for {platform_slug}",
            }
        with self._uow_factory() as uow:
            # The row is re-read because the label was resolved against a
            # snapshot: a background sync, a finishing download or the
            # removed-game cleanup can retire the ROM between the two
            # transactions, each on its own connection.
            rom = uow.roms.get(rom_id)
            if rom is None:
                return {
                    "success": False,
                    "reason": "not_found",
                    "message": f"ROM {rom_id} is not tracked",
                }
            if rom.platform_slug != platform_slug:
                # A re-sync rewrites platform_slug (it is a synced-identity
                # column). The label was validated against the platform the
                # snapshot named, so pinning it now would persist a label that
                # was never checked against the platform it will resolve under.
                # The message says exactly that rather than calling the label
                # unavailable: re-resolving to find out would cost the ES-DE
                # read this split exists to keep out of the transaction, and on
                # a label valid for both platforms "unavailable" is simply
                # false — the user retries and it works.
                return {
                    "success": False,
                    "reason": "core_unavailable",
                    "message": f"Emulator '{label}' was not verified for {rom.platform_slug}; try again",
                }
            # Enforce the aggregate invariant (strip / reject blank) via the
            # verb method, then persist the resulting label through the pin-only
            # write path (never the sync UPSERT).
            rom.pin_emulator_override(label)
            uow.roms.set_emulator_override(rom_id, rom.emulator_override)
            install = uow.rom_installs.get(rom_id)
        # Bake outside the committed write UoW, uniform with the clear path (the
        # pinned override is the just-resolved emulator, so there is no resolver
        # read and no commit-ordering subtlety here).
        launch_options, app_id = self._launch_options_for(rom, install, invocation)
        return {"success": True, "launch_options": launch_options, "app_id": app_id}

    async def clear_game_core(self, rom_id: int) -> dict[str, Any]:
        """Clear the per-game override for ``rom_id`` (Follow default / Reset).

        Drops the pin (stores SQL NULL) so the ROM follows the per-platform/system
        default, then returns the recomputed ``launch_options`` and ``app_id`` for
        an installed+bound ROM so the frontend confirm-sets the now-default launch
        on the live shortcut. Because the resolved default may itself be a
        per-platform core, the recomputed command bakes the ROM's FULL active core
        (the ``-e`` override form, or the plain launch when the platform resolves
        to ``(None, None)``) — never an unconditional plain launch. Clearing is
        always valid — there is no label to resolve. When the ROM is unknown the
        canonical failure shape is returned; when it is uninstalled or unbound the
        NULL still lands and ``launch_options``/``app_id`` are ``None``.
        """
        return await self._loop.run_in_executor(None, self._clear_game_core_io, rom_id)

    def _clear_game_core_io(self, rom_id: int) -> dict[str, Any]:
        with self._uow_factory() as uow:
            rom = uow.roms.get(rom_id)
            if rom is None:
                return {
                    "success": False,
                    "reason": "not_found",
                    "message": f"ROM {rom_id} is not tracked",
                }
            rom.clear_emulator_override()
            uow.roms.set_emulator_override(rom_id, rom.emulator_override)
            install = uow.rom_installs.get(rom_id)
        # Cleared pin → follow the per-platform/system default. The write UoW has
        # committed, so the resolver's own UoW now reads the landed NULL and
        # returns the POST-clear core — a per-platform core (or standalone system
        # default) still bakes its -e form. Resolving here (outside the closed
        # UoW) is also what keeps active_emulator_for_rom's BEGIN IMMEDIATE from
        # blocking on our write lock (#1047 / #1134). Skip the resolve entirely
        # when there is no live shortcut to update.
        if rom.shortcut_app_id is None or install is None:
            return {"success": True, "launch_options": None, "app_id": None}
        emulator = self._active_core.active_emulator_for_rom(rom_id)
        launch_options, app_id = self._launch_options_for(rom, install, emulator)
        return {"success": True, "launch_options": launch_options, "app_id": app_id}

    def _launch_options_for(
        self,
        rom: Rom,
        install: RomInstall | None,
        emulator: EmulatorInvocation | None,
    ) -> tuple[str | None, int | None]:
        """Bake the launch command for *rom* with *emulator*, or ``(None, None)``.

        Takes the ROM's ``RomInstall`` snapshot directly (``None`` when
        uninstalled) so the bake runs with no open Unit of Work — the callers
        snapshot the install inside their write UoW and close it before baking,
        since the shared active-core resolver opens its own UoW and the
        per-connection ``BEGIN IMMEDIATE`` write lock is not re-entrant.

        An installed (``RomInstall`` with a ``file_path``) **and** bound
        (``shortcut_app_id`` set) ROM gets the full launch command — the ``-e``
        form when *emulator* is set (libretro core or standalone), the plain form
        when it is ``None`` — over the disc-resolved bake path (the ROM's persisted
        ``selected_disc`` for a multi-disc ROM, its ``file_path`` unchanged for a
        single-disc ROM), paired with its Steam ``app_id``. An uninstalled or
        unbound ROM has no live shortcut to update, so both are ``None`` and the
        stored pin/clear applies on the next download/sync.
        """
        app_id = rom.shortcut_app_id
        if app_id is None or install is None:
            return (None, None)
        invocation = resolve_emulator_invocation({}, emulator)
        # Fold the ROM's persisted disc pick over the install so a per-game core
        # pin/clear re-bakes the pinned disc, not disc 1 / the m3u. A single-disc
        # ROM resolves to its own file_path.
        bake_path = self._disc_resolver.resolve_for_install(install, rom.selected_disc)
        return (build_launch_options(invocation, bake_path), app_id)

    def _appendconfig_for(self, platform_slug: str) -> str | None:
        """The generated RetroArch config for *platform_slug*, or ``None``.

        Mirrors the resolver's guard for the one bake site that resolves its own
        invocation: a generator that raises must not fail a pin write, and a missing
        file must bake exactly what the resolver would.
        """
        if self._appendconfig is None:
            return None
        try:
            return self._appendconfig(platform_slug)
        except Exception as exc:  # a save nicety must never break a pin
            self._logger.warning(f"cores: no appendconfig for {platform_slug}: {exc}")
            return None

    def _maybe_owned(self, invocation: EmulatorInvocation) -> EmulatorInvocation:
        """The same invocation, switched to a direct RetroArch launch when asked for.

        Mirrors the resolver's opt-in: only a libretro launch can be owned, and every
        reason not to own it (backend unset or different, no runner holding the core, a
        runner that raises) returns the invocation exactly as it was.
        """
        if invocation.kind != "libretro" or invocation.core_so is None:
            return invocation
        # Owned launch and bank travel together: without the redirect, a directly-started
        # RetroArch writes to its own directory and the save lookup looks elsewhere.
        if invocation.appendconfig is None:
            return invocation
        if self._retroarch_runner is None:
            return invocation
        if resolve_backend(self._settings.get("launch_backend")) != "retroarch":
            return invocation
        try:
            runner = self._retroarch_runner(invocation.core_so)
        except Exception as exc:  # an owned launch is never worth failing a pin over
            self._logger.warning(f"cores: no owned runner for {invocation.core_so}: {exc}")
            return invocation
        return invocation if runner is None else replace(invocation, runner=runner)

    def _read_rom(self, rom_id: int) -> Rom | None:
        with self._uow_factory() as uow:
            return uow.roms.get(rom_id)
