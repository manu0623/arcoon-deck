"""LibraryService façade.

Owns the public callable surface exposed via ``main.py`` (platform/
collection metadata, sync preview/apply/cancel, reporting, the
``roms``-derived queries) and the shared :class:`LibrarySyncStateBox` that
threads through every sub-service. Implementation lives in the
sub-service modules: :class:`LibraryFetcher` for ROM/metadata
roundtrips, :class:`SyncOrchestrator` for the preview/apply
lifecycle and safety heartbeat, :class:`SyncReporter` for post-apply
finalisation and the ``roms``-derived callable queries,
:class:`SessionBudgetMonitor` for Steam's renderer-heap budget,
:class:`ShortcutLaunchResolver` for each ROM's launch facts,
:class:`ChunkDispatcher` for one unit's emit → ack → commit round-trips,
:class:`CoverPreparer` for a unit's covers, :class:`SyncRunRecorder` for the
run's own ``SyncRun`` row, :class:`LocalLibraryReader` for what
this device already recorded about the library. The façade itself only wires the
pieces together and delegates — anything that touches RomM or mutates in-flight
sync state belongs in a sub-service.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from lib.late_binding import LateBinding
from services.library._state import CollectionMembership, LibrarySyncStateBox
from services.library.chunk_dispatcher import ChunkDispatcher, ChunkDispatcherConfig
from services.library.cover_preparer import CoverPreparer, CoverPreparerConfig
from services.library.fetcher import LibraryFetcher, LibraryFetcherConfig
from services.library.local_library_reader import LocalLibraryReader, LocalLibraryReaderConfig
from services.library.reporter import SyncReporter, SyncReporterConfig
from services.library.session_budget import SessionBudgetMonitor, SessionBudgetMonitorConfig
from services.library.shortcut_launch_resolver import ShortcutLaunchResolver, ShortcutLaunchResolverConfig
from services.library.sync_orchestrator import SyncOrchestrator, SyncOrchestratorConfig
from services.library.sync_run_recorder import SyncRunRecorder, SyncRunRecorderConfig

if TYPE_CHECKING:
    import asyncio
    import logging

    from domain.preview_delta import PreviewDelta
    from domain.sync_state import SyncState
    from services.protocols import (
        ActiveCoreReader,
        ArtworkManager,
        Clock,
        DebugLogger,
        DiscResolver,
        EventEmitter,
        RendererGcFn,
        RendererRssFn,
        RommLibraryApi,
        SettingsPersister,
        Sleeper,
        SteamConfigStore,
        UnitOfWorkFactory,
        UuidGen,
    )


@dataclass(frozen=True)
class LibraryServiceConfig:
    """Frozen wiring bundle handed to ``LibraryService.__init__``.

    Holds the Protocol-typed adapters, the live settings dict, runtime
    infrastructure, time/sleep/uuid seams, plugin-dir reference, event
    emitter, the ``settings.json`` persister and the SQLite Unit-of-Work
    factory (the synced-ROM registry, last-sync timestamp, sync stats and
    metadata cache now live in ``roms`` / ``sync_runs`` / ``rom_metadata``
    via the UoW), debug-logger seam, the artwork peer service, and the
    shared per-ROM ``active_core`` resolver (used to bake each ROM's full
    active core into ``launch_options`` at sync) and the shared ``disc_resolver``
    (used to bake each multi-disc ROM's selected disc into ``launch_options`` at
    sync). The ``renderer_rss`` / ``renderer_gc`` seams feed the session-budget
    gate: the RSS reader measures the Steam renderer's heap and the GC trigger
    settles it before a reading, so the apply can pause before Steam's per-session
    budget is exhausted.
    """

    romm_api: RommLibraryApi
    steam_config: SteamConfigStore
    settings: dict[str, Any]
    loop: asyncio.AbstractEventLoop
    logger: logging.Logger
    plugin_dir: str
    launcher_exe: str
    emit: EventEmitter
    clock: Clock
    uuid_gen: UuidGen
    sleeper: Sleeper
    settings_persister: SettingsPersister
    log_debug: DebugLogger
    artwork: ArtworkManager
    uow_factory: UnitOfWorkFactory
    active_core: ActiveCoreReader
    disc_resolver: DiscResolver
    renderer_rss: RendererRssFn
    renderer_gc: RendererGcFn


class LibraryService:
    """Façade for the library sync pipeline.

    Composes :class:`LibraryFetcher` (platform/collection roundtrips +
    metadata-cache stamping), :class:`SyncOrchestrator` (preview/apply lifecycle
    + safety heartbeat), :class:`SyncReporter` (post-apply finalisation + the
    ``roms``-derived callable queries), :class:`SessionBudgetMonitor` (Steam's
    renderer-heap budget), :class:`ShortcutLaunchResolver` (each ROM's installed
    path + active emulator), :class:`ChunkDispatcher` (one unit's apply, emitted
    and committed a chunk at a time), :class:`CoverPreparer` (a unit's covers,
    refreshed and downloaded before its shortcuts are emitted),
    :class:`SyncRunRecorder` (the run's ``SyncRun`` row, opened at its plan and
    closed at its outcome), and
    :class:`LocalLibraryReader` (this device's own record of the library, read
    back out of SQLite) over a single shared :class:`LibrarySyncStateBox`. The
    façade itself owns the box and exposes the callable surface; every
    implementation method lives on one of the sub-services.
    """

    def __init__(self, *, config: LibraryServiceConfig) -> None:
        self._config = config
        self._logger = config.logger
        self._box = LibrarySyncStateBox()

        # Sub-service: fetcher. Constructed first because the orchestrator
        # holds a reference to it for the per-unit fetch pipeline. The
        # progress-emit proxy late-binds to ``self._orchestrator`` so it
        # can be threaded into the fetcher's config before the
        # orchestrator exists.
        self._fetcher = LibraryFetcher(
            config=LibraryFetcherConfig(
                romm_api=config.romm_api,
                settings=config.settings,
                loop=config.loop,
                logger=config.logger,
                plugin_dir=config.plugin_dir,
                settings_persister=config.settings_persister,
                log_debug=config.log_debug,
                uow_factory=config.uow_factory,
                sync_state_box=self._box,
                emit_progress=self._emit_progress_proxy,
            )
        )

        # Sub-service: ShortcutLaunchResolver — resolves, per ROM, which file
        # is launched and which program runs it. Constructed before the
        # orchestrator, which holds it and resolves every bake's launch facts
        # through it.
        self._shortcut_launch_resolver = ShortcutLaunchResolver(
            config=ShortcutLaunchResolverConfig(
                uow_factory=config.uow_factory,
                active_core=config.active_core,
                disc_resolver=config.disc_resolver,
            )
        )

        # Sub-service: LocalLibraryReader — the fetcher's inward pair, reading
        # the local database where the fetcher reads RomM. Constructed before the
        # orchestrator, which holds it and offloads every one of its reads
        # through its own executor.
        self._local_library_reader = LocalLibraryReader(config=LocalLibraryReaderConfig(uow_factory=config.uow_factory))

        # Sub-service: session-budget monitor. Constructed before both holders:
        # the chunk dispatcher asks it at every chunk boundary, the orchestrator
        # for the preview prognosis, the run-start baseline and the terminal
        # memory delta.
        self._session_budget = SessionBudgetMonitor(
            config=SessionBudgetMonitorConfig(
                loop=config.loop,
                logger=config.logger,
                sync_state_box=self._box,
                renderer_rss=config.renderer_rss,
                renderer_gc=config.renderer_gc,
            )
        )

        # The orchestrator dispatches the per-unit pipeline's finalize
        # step (sync_collections + sync_complete) through the reporter, and
        # the chunk dispatcher commits every chunk through it, but the
        # reporter doesn't exist yet at this point in __init__. Thread the
        # forward reference through a LateBinding rather than writing to a
        # sub-service private after the fact.
        reporter_binding: LateBinding[SyncReporter] = LateBinding("reporter")

        # Sub-service: chunk dispatcher — one work unit's apply, emitted to the
        # frontend and committed a chunk at a time. Constructed before the
        # orchestrator, which holds it and hands it each unit's built delta.
        self._chunk_dispatcher = ChunkDispatcher(
            config=ChunkDispatcherConfig(
                logger=config.logger,
                emit=config.emit,
                clock=config.clock,
                sleeper=config.sleeper,
                sync_state_box=self._box,
                reporter=reporter_binding,
                session_budget=self._session_budget,
            )
        )

        # Sub-service: cover preparer — the apply path's covers, bound to this
        # run's progress and cancel signals. Constructed before the orchestrator,
        # which asks it for each unit's covers before the delta is handed to the
        # dispatcher. It is one of the two modules the ``artwork`` seam is
        # confined to; the reporter below is the other, for commit-time
        # cover-path finalisation.
        self._cover_preparer = CoverPreparer(
            config=CoverPreparerConfig(
                artwork=config.artwork,
                sync_state_box=self._box,
                emit_progress=self._emit_progress_proxy,
            )
        )

        # Sub-service: run recorder — the ``SyncRun`` row for this run.
        # Constructed before the orchestrator, which decides which terminal
        # status a stopped run earns and hands that decision here to be written.
        self._sync_run_recorder = SyncRunRecorder(
            config=SyncRunRecorderConfig(
                clock=config.clock,
                uow_factory=config.uow_factory,
            )
        )

        self._orchestrator = SyncOrchestrator(
            config=SyncOrchestratorConfig(
                settings=config.settings,
                loop=config.loop,
                logger=config.logger,
                launcher_exe=config.launcher_exe,
                emit=config.emit,
                clock=config.clock,
                uuid_gen=config.uuid_gen,
                uow_factory=config.uow_factory,
                sync_state_box=self._box,
                fetcher=self._fetcher,
                reporter=reporter_binding,
                shortcut_launch_resolver=self._shortcut_launch_resolver,
                local_library_reader=self._local_library_reader,
                session_budget=self._session_budget,
                chunk_dispatcher=self._chunk_dispatcher,
                cover_preparer=self._cover_preparer,
                sync_run_recorder=self._sync_run_recorder,
            )
        )

        self._reporter = SyncReporter(
            config=SyncReporterConfig(
                steam_config=config.steam_config,
                settings=config.settings,
                loop=config.loop,
                logger=config.logger,
                emit=config.emit,
                clock=config.clock,
                uow_factory=config.uow_factory,
                sync_state_box=self._box,
                emit_progress=self._emit_progress_proxy,
                artwork=config.artwork,
            )
        )
        reporter_binding.set(lambda: self._reporter)

    async def _emit_progress_proxy(self, stage, **kwargs):
        """Late-bound proxy to the orchestrator's emit_progress.

        Threaded into the fetcher's config at ctor time before
        ``self._orchestrator`` exists — calls resolve at invocation
        time, by which point both sub-services are wired.
        """
        await self._orchestrator.emit_progress(stage, **kwargs)

    # ── Public properties ────────────────────────────────────────

    @property
    def sync_state(self) -> SyncState:
        """Current sync state (read-only)."""
        return self._box.sync_state

    def is_sync_in_flight(self) -> bool:
        """True while a sync run is in flight (RUNNING or CANCELLING; IDLE is not).

        Read-only predicate consumed by the ``@sync_active_blocked`` gate on
        the destructive removal callables.
        """
        return self._box.is_in_flight()

    @property
    def pending_sync(self) -> dict[int, dict[str, Any]]:
        """Public accessor for pending sync data (used by SteamGridService)."""
        return self._box.pending_sync

    # ── State accessors preserving the pre-decomposition attribute shape ──
    #
    # The bootstrap-style ``get_pending_sync=lambda: service._pending_sync``
    # callback and fixture-level test setup poke at the legacy private
    # attribute names. Proxy them through the shared state box so external
    # readers and writers see the live values mutated by sub-services. The
    # run-lifecycle pair (``_sync_state`` / ``_current_sync_id``) is read-only
    # here: those two fields are written **only** through the box's verb
    # methods (``try_begin_run`` / ``request_cancel`` / ``finish_run``), so no
    # setter is exposed (#1202). ``_pending_delta`` is read-only for the same
    # reason — the staged preview is written only through ``stage_preview`` /
    # ``read_fresh_preview`` / ``discard_preview``.

    @property
    def _sync_state(self) -> SyncState:
        return self._box.sync_state

    @property
    def _pending_sync(self) -> dict[int, dict[str, Any]]:
        return self._box.pending_sync

    @_pending_sync.setter
    def _pending_sync(self, value: dict[int, dict[str, Any]]) -> None:
        self._box.pending_sync = value

    @property
    def _pending_delta(self) -> PreviewDelta | None:
        return self._box.pending_delta

    @property
    def _pending_collection_memberships(self) -> dict[tuple[str, str], CollectionMembership]:
        return self._box.pending_collection_memberships

    @_pending_collection_memberships.setter
    def _pending_collection_memberships(self, value: dict[tuple[str, str], CollectionMembership]) -> None:
        self._box.pending_collection_memberships = value

    @property
    def _pending_platform_rom_ids(self) -> set[int] | None:
        return self._box.pending_platform_rom_ids

    @_pending_platform_rom_ids.setter
    def _pending_platform_rom_ids(self, value: set[int] | None) -> None:
        self._box.pending_platform_rom_ids = value

    @property
    def _sync_progress(self) -> dict[str, Any]:
        return self._box.sync_progress

    @_sync_progress.setter
    def _sync_progress(self, value: dict[str, Any]) -> None:
        self._box.sync_progress = value

    @property
    def _sync_last_heartbeat(self) -> float:
        return self._box.sync_last_heartbeat

    @_sync_last_heartbeat.setter
    def _sync_last_heartbeat(self, value: float) -> None:
        self._box.sync_last_heartbeat = value

    @property
    def _current_sync_id(self) -> str | None:
        return self._box.current_sync_id

    @property
    def _settings(self) -> dict[str, Any]:
        return self._config.settings

    # ── Public callable surface ──────────────────────────────────

    def shutdown(self) -> None:
        """Request graceful shutdown — cancels sync if running."""
        self._orchestrator.shutdown()

    # Platform metadata
    async def get_platforms(self):
        return await self._fetcher.get_platforms()

    def save_platform_sync(self, platform_id, enabled):
        return self._fetcher.save_platform_sync(platform_id, enabled)

    async def set_all_platforms_sync(self, enabled):
        return await self._fetcher.set_all_platforms_sync(enabled)

    # Collection metadata
    async def get_collections(self):
        return await self._fetcher.get_collections()

    def save_collection_sync(self, collection_id, kind, enabled):
        return self._fetcher.save_collection_sync(collection_id, kind, enabled)

    def save_collections_sync(self, collection_ids, kind, enabled):
        return self._fetcher.save_collections_sync(collection_ids, kind, enabled)

    async def set_all_collections_sync(self, enabled, scope=None):
        return await self._fetcher.set_all_collections_sync(enabled, scope)

    # Sync control
    def start_sync(self):
        return self._orchestrator.start_sync()

    def cancel_sync(self, run_id=None):
        return self._orchestrator.cancel_sync(run_id)

    def sync_heartbeat(self):
        return self._orchestrator.sync_heartbeat()

    # Preview / apply
    async def sync_preview(self):
        return await self._orchestrator.sync_preview()

    async def sync_apply_delta(self, preview_id):
        return await self._orchestrator.sync_apply_delta(preview_id)

    def sync_cancel_preview(self):
        return self._orchestrator.sync_cancel_preview()

    def get_pending_preview(self):
        return self._orchestrator.get_pending_preview()

    def get_sync_status(self):
        return self._orchestrator.get_sync_status()

    async def get_session_budget_status(self):
        return await self._session_budget.get_session_budget_status()

    # Reporting
    async def report_unit_results(self, rom_id_to_app_id, run_id, unit_id, chunk_index):
        return await self._reporter.report_unit_results(rom_id_to_app_id, run_id, unit_id, chunk_index)

    # ``roms``-derived queries
    def get_registry_platforms(self):
        return self._reporter.get_registry_platforms()

    def clear_sync_cache(self):
        return self._reporter.clear_sync_cache()

    def get_sync_stats(self):
        return self._reporter.get_sync_stats()

    def get_sync_runs(self):
        return self._reporter.get_sync_runs()

    def get_rom_by_steam_app_id(self, app_id):
        return self._reporter.get_rom_by_steam_app_id(app_id)
